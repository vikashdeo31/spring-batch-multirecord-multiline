package hello;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PassThroughFieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.file.transform.PatternMatchingCompositeLineTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.batch.item.support.SingleItemPeekableItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;

import hello.domain.db.Person;
import hello.domain.file.PersonAbstract;
import hello.domain.file.Person_file;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    // tag::readerwriterprocessor[]
    @SuppressWarnings("unchecked")
	@Bean
    public FlatFileItemReader<PersonAbstract> reader() {
        return new FlatFileItemReaderBuilder<Person_file>()
            .name("personItemReader")
            .resource(new ClassPathResource("sample-data.csv"))
            .lineMapper(personFileLineMapper())
            .build();
    }
    
    
    @Bean
    public FixedLengthTokenizer fixedLengthPersonTokenizer() {
      FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
      tokenizer.setNames("prefix", "lastName", "firstName");
      tokenizer.setColumns(
    		  new Range(1,1),
    		  new Range(2,11),
    		  new Range(20,29)
    		  );
      return tokenizer;
    }
    
    @Bean
    public FixedLengthTokenizer fixedLengthPersonMobileTokenizer() {
      FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
      tokenizer.setNames("prefix", "value", "type");
      tokenizer.setColumns(
    		  new Range(1,1),
    		  new Range(12,22),
    		  new Range(23,38)
    		  );
      return tokenizer;
    }
    
    @Bean
    public FixedLengthTokenizer fixedLengthPersonEmailTokenizer() {
      FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
      tokenizer.setNames("prefix", "value", "type");
      tokenizer.setColumns(
    		  new Range(1,1),
    		  new Range(12,32),
    		  new Range(33,47)
    		  );
      return tokenizer;
    }
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	@Bean
    public PatternMatchingCompositeLineMapper personFileLineMapper() {
      @SuppressWarnings("rawtypes")
	PatternMatchingCompositeLineMapper lineMapper =
      new PatternMatchingCompositeLineMapper();
      Map<String, LineTokenizer> tokenizers = new HashMap<>(3);
      tokenizers.put("P*", fixedLengthPersonTokenizer());
      tokenizers.put("C*", fixedLengthPersonMobileTokenizer());
      tokenizers.put("E*", fixedLengthPersonEmailTokenizer());
      lineMapper.setTokenizers(tokenizers);
      Map<String, FieldSetMapper> mappers = new HashMap<>(3);
      mappers.put("P*", new PersonFieldSetMapper());
      mappers.put("C*", new PersonMobileFieldSetMapper());
      mappers.put("E*", new PersonEmailFieldSetMapper());
      lineMapper.setFieldSetMappers(mappers);
      return lineMapper;
    }
    
    
    @Bean
    public PatternMatchingCompositeLineTokenizer personFileTokenizer() {
      PatternMatchingCompositeLineTokenizer tokenizer =
      new PatternMatchingCompositeLineTokenizer();
      Map<String, LineTokenizer> tokenizers = new HashMap<>(3);
      tokenizers.put("P*", fixedLengthPersonTokenizer());
      tokenizers.put("C*", fixedLengthPersonMobileTokenizer());
      tokenizers.put("E*", fixedLengthPersonEmailTokenizer());
      tokenizer.setTokenizers(tokenizers);
      return tokenizer;
    }
    
    
    
    @SuppressWarnings("rawtypes")
	@Bean
    public FlatFileItemReader flatFileItemReader() {
      FlatFileItemReader<FieldSet> reader = new FlatFileItemReaderBuilder<FieldSet>()
      .name("flatFilePersonItemReader")
      .resource(new ClassPathResource("sample-data.csv"))
      .lineTokenizer(personFileTokenizer())
      .fieldSetMapper(new PassThroughFieldSetMapper())
      .build();
      return reader;
    }

    @SuppressWarnings("unchecked")
	@Bean
    public SingleItemPeekableItemReader<FieldSet> readerPeek() {
        SingleItemPeekableItemReader<FieldSet> reader = new SingleItemPeekableItemReader<FieldSet>() {{
            setDelegate(flatFileItemReader());
        }};
        return reader;
    }

    @SuppressWarnings("unchecked")
    @Bean
    public MultiLineCaseItemReader readerMultirecord() {
        MultiLineCaseItemReader multiReader = new MultiLineCaseItemReader() {{
            setDelegate(readerPeek());
        }};
        return multiReader;
    }
    
    
    

    @Bean
    public PersonItemProcessor processor() {
        return new PersonItemProcessor();
    }

  /*  @Bean
    public JdbcBatchItemWriter<Person> writer(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<Person>()
            .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
            .sql("INSERT INTO people (first_name, last_name) VALUES (:firstName, :lastName)")
            .dataSource(dataSource)
            .build();
    }
    
    */
    
    @Bean
    public ItemWriter<Person> simpleWriter(){
    	return new CustomItemWriter();
    }
    // end::readerwriterprocessor[]

    // tag::jobstep[]
    @Bean
    public Job importUserJob(JobCompletionNotificationListener listener, Step step1) {
        return jobBuilderFactory.get("importUserJob")
            .incrementer(new RunIdIncrementer())
            .listener(listener)
            .flow(step1)
            .end()
            .build();
    }

    @Bean
    public Step step1(ItemWriter<Person> simpleWriter) {
        return stepBuilderFactory.get("step1")
            .<Person_file, Person> chunk(1)
            .processor(processor())
            .writer(simpleWriter)
            .reader(readerMultirecord())
            .stream(flatFileItemReader())
            .build();
    }
    // end::jobstep[]
}
