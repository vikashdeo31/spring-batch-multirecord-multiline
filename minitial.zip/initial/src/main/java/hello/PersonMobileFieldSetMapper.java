package hello;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import hello.domain.file.PersonMobile_file;
import hello.domain.file.Person_file;

public class PersonMobileFieldSetMapper implements FieldSetMapper<PersonMobile_file> {

	@Override
	public PersonMobile_file mapFieldSet(FieldSet fs) throws BindException {
		if (fs == null) {
			return null;
		}
		
		PersonMobile_file pm = new PersonMobile_file();
		System.out.println("Prefix is == " + fs.readString("prefix"));
		pm.setPrefix(fs.readString("prefix"));
		pm.setType(fs.readString("type"));
		pm.setValue(fs.readString("value"));
		
		return pm;
	}

}
