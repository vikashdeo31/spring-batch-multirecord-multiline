package hello.domain.db;

import java.util.ArrayList;
import java.util.List;


public class Person {

    private String lastName;
    private String firstName;
    
    private List<PersonMobile> mobiles = new ArrayList<>();
    private List<PersonEmail> emails = new ArrayList<>();

    public Person() {
    }

    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
	public List<PersonMobile> getMobiles() {
		return mobiles;
	}

	public void setMobiles(List<PersonMobile> mobiles) {
		this.mobiles = mobiles;
	}

	public List<PersonEmail> getEmails() {
		return emails;
	}

	public void setEmails(List<PersonEmail> emails) {
		this.emails = emails;
	}

	@Override
    public String toString() {
        return "firstName: " + firstName + ", lastName: " + lastName;
    }

}
