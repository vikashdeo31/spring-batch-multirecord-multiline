package hello.domain.file;

import java.util.ArrayList;
import java.util.List;

public class Person_file implements PersonAbstract {

	private String prefix;
    private String lastName;
    private String firstName;
    private List<PersonMobile_file> mobiles = new ArrayList<>();
    private List<PersonEmail_File> emails = new ArrayList<>();

    public Person_file() {
    }

    public Person_file(String prefix, String firstName, String lastName) {
    	this.prefix = prefix;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	
	

	public List<PersonMobile_file> getMobiles() {
		return mobiles;
	}

	public void setMobiles(List<PersonMobile_file> mobiles) {
		this.mobiles = mobiles;
	}

	public List<PersonEmail_File> getEmails() {
		return emails;
	}

	public void setEmails(List<PersonEmail_File> emails) {
		this.emails = emails;
	}

	@Override
    public String toString() {
        return "firstName: " + firstName + ", lastName: " + lastName;
    }

}
