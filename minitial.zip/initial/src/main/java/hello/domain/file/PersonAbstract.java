package hello.domain.file;

public interface PersonAbstract {

}
