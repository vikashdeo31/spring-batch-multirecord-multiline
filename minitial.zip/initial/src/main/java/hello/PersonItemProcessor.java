package hello;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.ItemProcessor;

import hello.domain.db.Person;
import hello.domain.db.PersonEmail;
import hello.domain.db.PersonMobile;
import hello.domain.file.PersonAbstract;
import hello.domain.file.PersonEmail_File;
import hello.domain.file.PersonMobile_file;
import hello.domain.file.Person_file;

public class PersonItemProcessor implements ItemProcessor<Person_file, Person> {

    private static final Logger log = LoggerFactory.getLogger(PersonItemProcessor.class);

	@Override
	public Person process(Person_file item) throws Exception {
		
		Person transform_person = new Person(item.getFirstName(), item.getLastName()); 
		
		for (PersonMobile_file element : item.getMobiles()) {
			transform_person.getMobiles().add(new PersonMobile(element.getType(), element.getValue()));
		}
		
		for (PersonEmail_File element : item.getEmails()) {
			transform_person.getEmails().add(new PersonEmail(element.getType(), element.getValue()));
		}
		
		
		return transform_person;
	}



	

}
