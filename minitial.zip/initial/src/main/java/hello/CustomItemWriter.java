package hello;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

import hello.domain.db.Person;
import hello.domain.db.PersonEmail;
import hello.domain.db.PersonMobile;

public class CustomItemWriter implements ItemWriter<Person> {

	@Override
	public void write(List<? extends Person> items) throws Exception {
		
		for (Person person : items) {
			System.out.println("\n\nFrom writer --> " + person.getFirstName() + " -- " + person.getLastName());
			
			System.out.println("Person has number of mobiles = " + person.getMobiles().size());
			for (PersonMobile mobile  : person.getMobiles()) {
				System.out.println("Mobile type = " + mobile.getType() + " | Mobile Number = " + mobile.getValue());
			}
			
			System.out.println("Person has number of emails = " + person.getEmails().size());
			for(PersonEmail email : person.getEmails()) {
				System.out.println("Email type = " + email.getType() + " | Email Address  = " + email.getValue());
			}
		}
		
	}
	

}
