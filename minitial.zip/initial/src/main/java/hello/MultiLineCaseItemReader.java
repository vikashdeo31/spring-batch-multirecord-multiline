package hello;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.batch.item.support.SingleItemPeekableItemReader;

import hello.domain.file.PersonEmail_File;
import hello.domain.file.PersonMobile_file;
import hello.domain.file.Person_file;

public class MultiLineCaseItemReader implements ItemReader<Person_file> {
	
	private SingleItemPeekableItemReader<FieldSet> delegate;

	public SingleItemPeekableItemReader<FieldSet> getDelegate() {
		return delegate;
	}
	

	public void setDelegate(SingleItemPeekableItemReader<FieldSet> delegate) {
		this.delegate = delegate;
	}
	
	
	public Person_file read () throws Exception {
		Person_file  person = null;
		//this.delegate.open(new ExecutionContext());
		
		for(FieldSet line = null; (line = this.delegate.peek()) != null;) {
			String prefix = line.readString("prefix");
			
			if(prefix.equalsIgnoreCase("p")) {
				// this is person object 
				//So will check if our scoped person is null. If yes that means this is the first time 
				// person is coming to us. if not null we need to consider it end.
				
				if(person == null) {
					this.delegate.read();
					person = new Person_file(prefix, line.readString("firstName"), line.readString("lastName"));
				}else {
					return person;
				}
			}else if(prefix.equalsIgnoreCase("c")) {
				this.delegate.read();
				if(person != null) {
					person.getMobiles().add(new PersonMobile_file(prefix, line.readString("type"), line.readString("value")));
				}
				
			}else if(prefix.equalsIgnoreCase("e")) {
				this.delegate.read();
				if(person != null) {
					person.getEmails().add(new PersonEmail_File(prefix, line.readString("type"), line.readString("value")));
				}
			}
		}
		return person;
	}	

}
