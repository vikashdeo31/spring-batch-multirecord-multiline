package hello;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import hello.domain.file.Person_file;

public class PersonFieldSetMapper implements FieldSetMapper<Person_file> {

	@Override
	public Person_file mapFieldSet(FieldSet fs) throws BindException {
		if (fs == null) {
			return null;
		}
		
		Person_file p = new Person_file();
		System.out.println("Prefix is == " + fs.readString("prefix"));
		p.setPrefix(fs.readString("prefix"));
		p.setLastName(fs.readString("lastName"));
		p.setFirstName(fs.readString("firstName"));
		
		return p;
	}

}
